<?= $this->extend('admin/layout.php'); ?>
<?= $this->section('content'); ?>

<!-- Form untuk memilih bulan dan tahun -->
<form method="get" action="<?= base_url('admin/ketidakhadiran') ?>">
    <div class="row mb-3">
        <div class="col-md-4">
            <label for="bulan" class="form-label">Pilih Bulan</label>
            <select id="bulan" name="bulan" class="form-select">
                <?php
                $months = [
                    '01' => 'Januari',
                    '02' => 'Februari',
                    '03' => 'Maret',
                    '04' => 'April',
                    '05' => 'Mei',
                    '06' => 'Juni',
                    '07' => 'Juli',
                    '08' => 'Agustus',
                    '09' => 'September',
                    '10' => 'Oktober',
                    '11' => 'November',
                    '12' => 'Desember'
                ];
                foreach ($months as $key => $month) {
                    $selected = isset($_GET['bulan']) && $_GET['bulan'] == $key ? 'selected' : '';
                    echo "<option value=\"$key\" $selected>$month</option>";
                }
                ?>
            </select>
        </div>
        <div class="col-md-4">
            <label for="tahun" class="form-label">Pilih Tahun</label>
            <input type="number" id="tahun" name="tahun" class="form-control" value="<?= isset($_GET['tahun']) ? htmlspecialchars($_GET['tahun']) : date('Y') ?>" />
        </div>
        <div class="col-md-4 d-flex align-items-end">
            <button type="submit" class="btn btn-primary">Tampilkan</button>
        </div>
    </div>
</form>

<a href="<?= base_url('admin/ketidakhadiran/create') ?>" class="btn btn-primary mb-3"><i class="bi bi-plus-circle"></i>Tambah Data</a>

<table class="table table-striped table-bordered" id="datatables">
    <thead class="thead-dark">
        <tr>
            <th scope="col">No</th>
            <th scope="col">Nama Pegawai</th> <!-- Ubah dari ID Pegawai ke Nama Pegawai -->
            <th scope="col">Keterangan</th>
            <th scope="col">Tanggal Awal</th>
            <th scope="col">Tanggal Akhir</th>
            <th scope="col">Detail</th>
            <th scope="col">Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $no = 1;
        foreach ($ketidakhadiran as $kh) : ?>
            <tr>
                <td><?= $no++ ?></td>
                <td><?= htmlspecialchars($kh['nama_pegawai']) ?></td> <!-- Ubah dari $kh['id_pegawai'] ke $kh['nama_pegawai'] -->
                <td><?= htmlspecialchars($kh['keterangan']) ?></td>
                <td><?= htmlspecialchars(date('d-m-Y', strtotime($kh['tanggal_awal']))) ?></td>
                <td><?= htmlspecialchars(date('d-m-Y', strtotime($kh['tanggal_akhir']))) ?></td>
                <td>
                    <a href="<?= base_url('admin/ketidakhadiran/detail/' . $kh['id']) ?>" class="badge bg-secondary">Klik untuk detail</a>
                </td>
                <td>
                    <a href="<?= base_url('admin/ketidakhadiran/edit/' . $kh['id']) ?>" class="badge bg-primary">Edit</a>
                    <a href="<?= base_url('admin/ketidakhadiran/delete/' . $kh['id']) ?>" class="badge bg-danger delete-button">Hapus</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<?= $this->endSection(); ?>