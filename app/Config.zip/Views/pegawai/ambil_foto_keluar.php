<?= $this->extend('pegawai/layout.php'); ?>

<?= $this->section('content'); ?>
<script 
    src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js" 
    integrity="sha512-dQIiHSl2hr3NWKKLycPndtpbh5iaHLo6MwrXm7F0FM5e+kL2U16oE9uIwPHUl6fQBeCthiEuV/rzP3MiAB8Vfw==" 
    crossorigin="anonymous" 
    referrerpolicy="no-referrer"
></script>
 
<input type="hidden" id="tanggal_keluar" value="<?= $tanggal_keluar ?>">
<input type="hidden" id="jam_keluar" value="<?= $jam_keluar ?>">

<div class="card col-4 align-items-center">
    <div class="card-body">
        <div class="row">
            <div class="input-style-1"> 
                <div id="my_camera"></div>
                <div style="display: none;" id="my_result"></div>
            </div>
            <div class="input-style-1">
                <label>Catatan</label>
                <textarea name="catatan_keluar" id="catatan_keluar" placeholder="Tulis catatan"></textarea>
            </div>
        </div>
        <button class="btn btn-danger mt-2" id="ambil-foto-keluar">Absensi Pulang</button>
    </div>
</div>

<script>
    Webcam.set({
        width: 320,
        height: 240,
        dest_width: 320,
        dest_height: 240,
        image_format: 'jpeg',
        jpeg_quality: 90,
        force_flash: false
    });
    Webcam.attach('#my_camera');

    document.getElementById('ambil-foto-keluar').addEventListener('click', function(){
        let tanggal_keluar = document.getElementById('tanggal_keluar').value;
        let jam_keluar = document.getElementById('jam_keluar').value;
        let catatan_keluar = document.getElementById('catatan_keluar').value;

        Webcam.snap(function(data_uri){
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                document.getElementById('my_result').innerHTML = '<img src="' + data_uri + '"/>'
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    window.location.href = "<?= base_url('pegawai/home') ?>"
                }
            };
            xhttp.open("POST", "<?= base_url('pegawai/presensi_keluar_aksi/' . $id_presensi) ?>", true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send(
                'foto_keluar=' + encodeURIComponent(data_uri) +
                '&tanggal_keluar=' + tanggal_keluar +
                '&jam_keluar=' + jam_keluar + 
                '&catatan_keluar=' +catatan_keluar
            );
            console.log(encodeURIComponent(data_uri));
        });
    });


</script>

<?= $this->endSection(); ?>