<?= $this->extend('pegawai/layout.php'); ?>
<?= $this->section('content'); ?>

<style>
    @media (max-width: 768px) {

        .table td,
        .table th {
            white-space: nowrap;
            /* Mencegah teks melintasi baris */
        }

        .status-center-mobile {
            display: flex;
            justify-content: center;
            align-items: center;
            text-align: center;
            /* Menjamin teks berada di tengah */
        }
    }
</style>

<form method="get" action="<?= base_url('pegawai/rekap_presensi') ?>" class="mb-3">
    <div class="row gx-2">
        <div class="col-6 col-md-3 mb-2">
            <select name="bulan" class="form-select" onchange="this.form.submit()">
                <?php for ($i = 1; $i <= 12; $i++) : ?>
                    <option value="<?= $i ?>" <?= $i == $bulan ? 'selected' : '' ?>>
                        <?= date('F', mktime(0, 0, 0, $i, 1)) ?>
                    </option>
                <?php endfor; ?>
            </select>
        </div>
        <div class="col-6 col-md-3 mb-2">
            <input type="number" name="tahun" class="form-control" value="<?= $tahun ?>" min="2000" max="<?= date('Y') ?>" onchange="this.form.submit()">
        </div>
    </div>
</form>

<?php foreach ($rekap_presensi as $rp) : ?>
    <div class="row my-2 mx-1 border" style="border-radius: 10px;">
        <div class="col-2 text-center pt-10 pb-15 d-flex flex-column status-center-mobile" style="border-left:10px solid <?= $rp['status'] == 'Tepat Waktu' ? 'green' : 'orange' ?>; border-radius: 10px;">
            <p class="mt-2 mt-md-0" style="font-size:small"><?= strtoupper(substr(date('F', strtotime($rp['tanggal_masuk'])), 0, 3)) ?><br><b><?= date('d', strtotime($rp['tanggal_masuk'])) ?></b></p>
        </div>
        <div class="col-2 d-flex pt-4 pb-0 text-center">
            <p><?= htmlspecialchars($rp['hari']) ?></p>
        </div>
        <div class="col-4 d-flex pt-3 pb-0 text-center">
            <p><?= htmlspecialchars(substr($rp['jam_masuk'], 0, 5) . '  -  ' . (substr($rp['jam_keluar'], 0, 5) == '00:00' ? '--:--' : substr($rp['jam_keluar'], 0, 5))) ?></p>
        </div>
        <div class="col-4 <?= $rp['status'] == 'Tepat Waktu' ? 'pt-4 pb-0' : 'pt-3 pb-0' ?>">
            <p style="font-size: 14px; color: <?= $rp['status'] == 'Tepat Waktu' ? 'green' : 'orange' ?>;"><?= htmlspecialchars($rp['status']) ?></p>
            <p style="font-size: 12px;"><?= htmlspecialchars($rp['keterlambatan']) ?></p>
        </div>
    </div>
<?php endforeach; ?>


<!-- <div class="table-responsive">
    <table class="table table-striped table-bordered text-center table-hover" id="datatables">
        <thead class="thead-dark">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Tanggal</th>
                <th scope="col">Hari</th>
                <th scope="col">Status</th>
                <th scope="col">Keterlambatan</th>
            </tr>
        </thead>
        <tbody>
            <?php $no = 1; ?>
            <?php foreach ($rekap_presensi as $rp) : ?>
                <tr>
                    <th style="border-left: 4px solid <?= $rp['status'] == 'Tepat Waktu' ? 'green' : 'orange' ?>"><?= $no++ ?></th>
                    <td style="border-left: 4px solid <?= $rp['status'] == 'Tepat Waktu' ? 'green' : 'orange' ?>"><?= date('d', strtotime($rp['tanggal_masuk'])) ?><br><?= date('F', strtotime($rp['tanggal_masuk'])) ?></td>
                    <td><?= htmlspecialchars($rp['hari']) ?></td>
                    <td><?= htmlspecialchars($rp['status']) ?></td>
                    <td><?= htmlspecialchars($rp['keterlambatan']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div> -->

<?= $this->endSection(); ?>