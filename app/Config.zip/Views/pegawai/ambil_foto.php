<?= $this->extend('pegawai/layout.php'); ?>

<?= $this->section('content'); ?>
<script 
    src="https://cdnjs.cloudflare.com/ajax/libs/webcamjs/1.0.26/webcam.min.js" 
    integrity="sha512-dQIiHSl2hr3NWKKLycPndtpbh5iaHLo6MwrXm7F0FM5e+kL2U16oE9uIwPHUl6fQBeCthiEuV/rzP3MiAB8Vfw==" 
    crossorigin="anonymous" 
    referrerpolicy="no-referrer"
></script>

<input type="hidden" id="id_pegawai" value="<?= $id_pegawai ?>">
<input type="hidden" id="tanggal_masuk" value="<?= $tanggal_masuk ?>">
<input type="hidden" id="jam_masuk" value="<?= $jam_masuk ?>">

<div class="card col-4 align-items-center">
    <div class="card-body">
        <div class="row">
            <div class="input-style-1"> 
                <div id="my_camera"></div>
                <div style="display: none;" id="my_result"></div>
            </div>
            <div class="input-style-1">
                <label>Catatan</label>
                <textarea name="catatan_masuk" id="catatan_masuk" placeholder="Tulis catatan"></textarea>
            </div>
        </div>
        <button class="btn btn-primary mt-2" id="ambil-foto">Absensi Masuk</button>
    </div>
</div>


<script>
    Webcam.set({
        width: 320,
        height: 240,
        dest_width: 320,
        dest_height: 240,
        image_format: 'jpeg',
        jpeg_quality: 90,
        force_flash: false
    });
    Webcam.attach('#my_camera');

    document.getElementById('ambil-foto').addEventListener('click', function(){
        let id = document.getElementById('id_pegawai').value;
        let tanggal_masuk = document.getElementById('tanggal_masuk').value;
        let jam_masuk = document.getElementById('jam_masuk').value;
        let catatan_masuk = document.getElementById('catatan_masuk').value;
        console.log(id, tanggal_masuk, jam_masuk)

        Webcam.snap(function(data_uri){
            var xhttp = new XMLHttpRequest();
            xhttp.onreadystatechange = function() {
                document.getElementById('my_result').innerHTML = '<img src="' + data_uri + '"/>'
                if (xhttp.readyState == 4 && xhttp.status == 200) {
                    window.location.href = "<?= base_url('pegawai/home') ?>"
                }
            };
            xhttp.open("POST", "<?= base_url('pegawai/presensi_masuk_aksi') ?>", true);
            xhttp.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
            xhttp.send(
                'foto_masuk=' + encodeURIComponent(data_uri) + 
                '&id_pegawai=' + id +
                '&tanggal_masuk=' + tanggal_masuk +
                '&jam_masuk=' + jam_masuk +
                '&catatan_masuk=' + catatan_masuk
            );
            console.log(encodeURIComponent(data_uri));
        });
    });


</script>

<?= $this->endSection(); ?>