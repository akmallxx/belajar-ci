<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use CodeIgniter\HTTP\ResponseInterface;
use App\Models\UserModel;
use App\Models\PresensiModel;

class Home extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();
        $presensiModel = new PresensiModel();

        $data = [
            'title'             => session()->get('role_id') . ' Dashboard',
            'total_pegawai'     => $userModel->where('role', 'Pegawai')->where('status', 'Aktif')->countAllResults(),
            'total_presensi'    => $presensiModel->where('tanggal_masuk', date('Y-m-d'))->countAllResults()
        ];
        return view('admin/index', $data);
    }
}
